drop database if exists monopatinElectrico;
create database monopatinElectrico;
use monopatinElectrico;

create table clientes(
    id int auto_increment primary key not null,
    dni varchar(10) not null ,
    nombre varchar(25) not null ,
    apellido varchar(25) not null ,
    telefono varchar(15) ,
    direccion varchar(30) ,
    email varchar(30)
);

create table proveedores(
    id int auto_increment primary key not null,
    cuit varchar(20) not null ,
    razonSocial varchar(35) not null ,
    email varchar(30),
    telefono varchar(20) 
);

create table monopatines(
    id int auto_increment primary key not null ,
    idProveedor int,
    modelo varchar(30),
    precio int,
    estado enum('ALQUILADO','DISPONIBLE') not null,
    foreign key (idProveedor)
    references proveedores(id)
    
);


create table alquileres(
    id int auto_increment not null,
    fechaAlquiler date not null,
    fechaDevolucion date ,
    idCliente int,
    idMonopatin int,
    primary key(id,idCliente,idMonopatin),
    foreign key (idCliente)
    references clientes(id),
    foreign key(idMonopatin)
    references monopatines(id)
    
);

insert into clientes (dni,nombre,apellido,telefono,direccion,email)
		      values('33010590','Eric','Cuevas','46525642','olavarria 550 ','ericcuevas@gmail.com'),
			    ('31626211','Cynthia','Diaz','1168296511','Desaguadero 3244 ','cyDiaz@gmail.com'),
                            ('29656147','David','Gonzalez','44544471','Suarez 2550 ','kummax2@gmail.com'),
                            ('14313318','Juan Ramon','Nogueira','43820327','Directorio 3960','Nogueira@gmail.com'),
                            ('12532898','Hector','Acuña','1168296533','Uruguay 2030','Hector2020@gmail.com'),
                            ('32236912','Ezequiel','Altamirano','1127132065','Merlo 1031','EzequielAltamirano@gmail.com'),
                            ('26424525','Julian','Perez','1129132055','Lujan 546','Jualianoo@gmail.com');
            

insert into proveedores (cuit,razonSocial,email,telefono)
                        values ('23-33010590-9','El Estanque SRL','ElEstanque@yahoo.com.ar','46265726'),
                               ('23-22236852-9','El Farolito SA','ElFarolito@yahoo.com.ar','48525669'),
                               ('20-24885012-4','Monopatines Express SRL','MonopatinesExpress@gmail.com','46552354'),
                               ('20-29852741-6','Del Sur Monopatines SA','DelSurMonopatines@gmail.com','47419632'),
                               ('20-29852741-6','MonopatinesYa SRL','MonopatinesYa@gmail.com','47271130');

insert into monopatines (idProveedor,modelo,precio,estado)
                        values	(2,'asf2020',300,'DISPONIBLE'),
                                (4,'MAX-1204',400,'DISPONIBLE'),
                                (5,'LQS-10',500,'DISPONIBLE'),
                                (3,'SCOOTER21',600,'DISPONIBLE'),
                                (1,'SPEEDFAST',700,'DISPONIBLE');

insert into alquileres (fechaAlquiler,fechaDevolucion,idCliente,idMonopatin)
                        values ('2019/7/31','2019/8/1',1,2),
                               ('2019/8/29','2019/8/30',5,2),
                               ('2020/6/20','2020/6/21',3,2),
                               ('2020/3/31','2020/4/1',3,4),
                               ('2020/5/3','2020/5/4',6,5),
                               ('2020/5/10','2020/5/12',2,1),
                               ('2019/3/31','2019/4/2',4,4),
                               ('2019/9/29','2019/9/30',7,5);